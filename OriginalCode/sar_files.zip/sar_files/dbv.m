function out = dbv(in)

out = 20 * log10(abs(in));
